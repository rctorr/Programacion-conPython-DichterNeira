import click
import os
import time

class Archivo():
    def __init__(self, ruta):
        """ Crea un objeto Archivo a partir de ruta """
        self.__ruta = ruta
        try:
            self.tamanio = os.path.getsize(ruta)
            self.fecha = os.path.getmtime(ruta)
        except FileNotFoundError:
            pass
        except OSError:
            pass

    @property
    def get_ruta(self):
        """ Obtiene el valor de ruta """
        return self.__ruta

    def __str__(self):
        """ Define la represrentación en str de Archivo """
        return self.__ruta

    def texto(self):
        """ Representación en texto plano de un Archivo """
        fecha: tuple = time.localtime(self.fecha)
        fecha: str = time.strftime("%d-%m-%Y %H:%M:%S", fecha)
        return f"{self.tamanio:12}  {fecha:19}  {self.__ruta}"

class Carpeta(Archivo):
    def lista_elementos(self):
        """ Obtener la lista de elementos de la Carpeta """
        try:
            archivos: list = os.listdir(self.get_ruta)  # archivos -> ["uno.py", "dos.py", ...]
        except PermissionError:
            archivos = []
        # elementos -> [Archivo("uno.py"), Archivo("dos.py"), Carpeta("datos"), ....]
        elementos = []
        for arch in archivos:
            # arch -> ruta + "uno.py", "datos"
            ruta = os.path.join(self.get_ruta, arch)  # "/home/rcotrr/uno.py"
            if os.path.isdir(ruta):
                carpeta = Carpeta(ruta)
                elementos.append( carpeta )
                # elementos = elementos + Carpeta(ruta).lista_elementos()
                elementos += carpeta.lista_elementos()
                # i = i + 1
                # i += 5
                # i -= 5
                # i *= 2 -> i = i * 2
                # i++ <- No existe en Python
            else:
                elementos.append( Archivo(ruta) )
        return elementos

    def texto(self):
        """ Representación en texto plano de un Archivo """
        return super().texto() + "/"


def imprime_en_texto(lista):
    """
    Imprime los elementos de lista en la salida estándar en
    formato texto plano.
    """
    for arch in lista:  # lista -> [Archivo(), Carpeta(), Archuvo(), ...]
        # type(arch) ? , str [x], Archivo() o Carpeta()
        print( arch.texto() )

@click.command()
@click.argument("carpeta", default=".", type=click.Path(exists=True))
def main(carpeta):
    """
    Imprime la lista de archivos y carpetas de la carpeta actual o de la
    CARPETA proporcionada por el usuario.
    """
    carpeta_obj = Carpeta(carpeta)
    elementos: list = carpeta_obj.lista_elementos()
    imprime_en_texto(elementos)

if __name__ == '__main__':
    main()
