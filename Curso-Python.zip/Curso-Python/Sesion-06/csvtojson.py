# 1. leer la información de la línea comando: nombre de archivo
# 2. Crear el nombre de archivo de salida
# 3. leer los datos del archivo csv
# 4. escribir los datos en el archivo json
# 4.1 Obtener las etiquetas de las columnas o campos

import click
import csv
import json
import os


def lee_csv(archivo):
	""" Lee los registro del archivo en formato csv """

	with open(archivo, "rt") as arch:
		csv_lector = csv.reader(arch, delimiter=";")
		# datos = []
		# for fila in csv_lector:
		#	datos.append(fila)
		datos = list(csv_lector)
		# [
		#    (col1, col2, col3, ...),
		#    [col1, col2, col3, ...],
		#    [col1, col2, col3, ...],
		#    [col1, col2, col3, ...]
		# ]

	return datos

def escribe_json(archivo_salida, datos):
	""" Escribe los datos en archivo_salida en formato JSON """
	etiquetas = datos[0]  # Tamaño;Fecha;Nombre
	datos_dicts = []
	for fila in datos[1:]:
		fila_dict = {}
		for i, etiqueta in enumerate(etiquetas):  # [(0, "Tamaño"), (1, "Fecha"), ...]
			fila_dict[etiqueta] = fila[i]
		datos_dicts.append(fila_dict)
	with open(archivo_salida, "w") as arch_salida:
		# arch_salida.write( json.dumps(datos_dicts, indent=4) )
		json.dump(datos_dicts, arch_salida, indent=4)


@click.command()
@click.argument("archivo", type=click.Path(exists=True))
def main(archivo):
    """
    Converite un archivo CSV a JSON
    """
    # archivo_salida = archivo.split(".")[0] + ".json"  # ["salida", "csv"]
    archivo_salida = os.path.splitext(archivo)[0] + ".json"

    datos = lee_csv(archivo)
    escribe_json(archivo_salida, datos)


if __name__ == '__main__':
    main()
