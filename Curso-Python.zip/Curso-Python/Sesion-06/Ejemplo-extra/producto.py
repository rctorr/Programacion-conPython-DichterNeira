import json
import sqlite3

# Definición de constantes
NOMBRE_JSON = "productos.json"
NOMBRE_CSV = "productos.csv"

class Producto():
    """ Define los objetos de tipo Producto """
    def __init__(self, id_, nombre, cantidad, precio):
        """ constructor de la clase """
        self.id = id_
        self.nombre = nombre
        self.cantidad = cantidad
        self.precio = precio
    @property
    def subtotal(self):
        """ Calcula el subtotal en tiempo real """
        return self.cantidad * self.precio
    def __str__(self):
        """ Representación en str de un Producto """
        return f"({self.id:>3}) {self.nombre:>10} {self.cantidad:>3.0f} {self.precio:>10.2f}"
    def to_dict(self):
        """ Regresar en diccionario el Producto """
        return {
            "id": self.id,
            "nombre": self.nombre,
            "cantidad": self.cantidad,
            "precio": self.precio,
        }

def imprimir_productos(productos):
    """ Imprime en la salida estándar la lista de productos """
    print("#" * 20)
    for producto in productos:
        print(producto)
    print("#" * 20)


def importar_de_json():
    """ Obtener la lista de elementos de productos de json """
    elementos = []
    ruta = "productos.json"
    with open(ruta, "r", encoding="utf-8" ) as arch_texto:
        data = json.load(arch_texto)
    for prod_dict in data:  # [producto1_dict, prod2_dict, ....]
        producto = Producto(*prod_dict.values())  # id, nombre, precio,
        elementos.append( producto )

    return elementos

