# Format sirve para añadir variables dentro de una cadena durante la ejecución
nombre = "Luis"  
print("Hola, mi nombre es {}".format(nombre) )

# Incluso se pueden agregar variables que no son cadenas
edad = 28
print("{} Tengo {} años".format(nombre, edad))

# O se pueden agregar multiples datos
print("{} + {} = {}".format(4, 5, 4+5))

# Haciendo uso de f-strings
print( f"Hola, mi nombre es {nombre}" )

print( f"Tengo {edad} años" )

print( f"{4} + {5} = {4+5}" )


