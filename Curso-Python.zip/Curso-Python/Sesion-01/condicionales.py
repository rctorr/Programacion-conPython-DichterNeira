# if forma más simple
edad = 18
if edad >= 18:
	print("Bienvenid@ a nuestra red social!")
	print("fin del bloque verdadero")
print("Más allá del if")

# if - else
print()  # imprime una línea en blanco
velocidad = 80
limite = 50
if velocidad <= limite:
	print("Eres buen conductor!")
else:
	print("Te has hecho acreedor a una multa!")
print("Más allá del if")

# if - elif - elif - ... - else: switch o case
print()
numero = 57
if numero < 0:
	print("El número es negativo!")
elif numero == 0:
	print("El número es cero")
else:
	print("El número es positivo")
