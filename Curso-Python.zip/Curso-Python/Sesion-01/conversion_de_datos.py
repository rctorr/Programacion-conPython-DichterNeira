numero1 = "100"
numero2 = "3.14159"
print( type(numero1), type(numero1) )

entero = int(numero1)
print( entero, type(entero) )

flotante = float(numero2)
print( flotante, type(flotante) )

num = 300
cadena = str(num)
print(cadena, type(cadena))

nombre = input("Dame tu nombre: ")
print( nombre, type(nombre) )

edad_str = input("Dame tu edad: ")
edad = int(edad_str)
print( edad, type(edad) )

edad = int( input("Dame tu edad: ") )
print( edad, type(edad) )

