entero = 31
print( "El dato introducido contiene:", entero )
print( "Es de tipo:", type(entero) )

entero = 31.5
print( "El dato introducido contiene:", entero )
print( "Es de tipo:", type(entero) )

pi = 3.14159
print("El dato introducido contiene:", pi)
print("Es de tipo:", type(pi) )

mensaje = "Hola Mundo"
print("El dato introducido contiene:", mensaje)
print("Es de tipo:", type(mensaje) )

mensaje = "P"
print("El dato introducido contiene:", mensaje)
print("Es de tipo:", type(mensaje) )

mensaje = ""
print("El dato introducido contiene:", mensaje)
print("Es de tipo:", type(mensaje) )

verdadero = True  # False
print("El dato introducido contiene:", verdadero)
print("Es de tipo:", type(verdadero) )

