incremento = 1

incremento = incremento + 1  # incremento -> 2
print("El resultado es:", incremento)

incremento += 1  # incremento -> 3
print("El resultado es", incremento)

incremento += 5  # incremento -> 8
print("El resultado es", incremento)


operando3 = True
operando4 = False

compuerta_and = operando3 and operando4  # False, &&, &
print("El resultado de la AND es", compuerta_and)

negando = not operando3  # False
print("Esto es una negación", negando)
