import click
import tiempo

@click.command()
@click.argument("n", type=int)
@tiempo.tiempo_ejecucion
def main(n):
    """ Imprime una lista de número en la salida estándar de longitud N """
    numeros = list(range(n))
    for i in numeros:
        print(i)
        
if __name__ == "__main__":
    main()