libros = (
    "El señor de los anillos",
    "El árte de la guerra",
    "Triptofanito",
    "La Meta",
    "El árte de la guerra",
    "La Meta",    
)

# Eliminando duplicados
libros: set = set(libros)

# Ordenando
# list.sort()
libros: list = list(libros)
libros.sort()

# Uniendo lineas de texto, en una sola línea de texto:
for libro in libros:
    print(libro)

