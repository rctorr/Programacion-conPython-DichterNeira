# Creando tuplas vacias
tupla_vacia = ()
tuplas_vacia2 = tuple()

# Iniciando tuplas con datos
tupla_enteros = (4, 8, 3, 2, 9, 11, 4, 1, 4, 3)
#                0  1  2  3  4  5   6  7  8  9
tupla_floats = (4.5, 8.5, 2.5, 9.5)
tupla_cadenas = ("cuatro", "ocho", "dos")

print(tupla_vacia)
print(tupla_enteros)
print(tupla_cadenas)

# Creando tupla con varios tipos de datos
tupla_mix = (4, 4.5, "cuatro")
tupla_tuplas = (tupla_vacia, tupla_enteros, tupla_mix)

print(tupla_tuplas)

# Tipos de operaciones

print(tupla_enteros[0])  # primer elemento
print(tupla_enteros[2])  # tercer elemento
print(tupla_enteros[9])  # el último elemento
print( len(tupla_enteros) )  # cantidad de elementos en una tupla
print(tupla_enteros[len(tupla_enteros)-1])  # el último elemento
print(tupla_enteros[-1])  # el último elemento
print("-" * 40)

# Obtener rebanadas (slices)

print(tupla_enteros[2:6])
print(tupla_enteros[:6])
print(tupla_enteros[2:])

print("-" * 40)

# Convertir cadenas a tuplas o lo contrario
texto = "abcdefg hijk"
tupla = tuple(texto)
print(tupla)

texto2 = "".join(tupla)  # abcdefg hijk
print(texto2)

lista = list(tupla)
lista.sort()
print(lista)