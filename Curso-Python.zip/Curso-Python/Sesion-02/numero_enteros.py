# 1. Obtener n
n: str = input("Dame un número entero: ")
n: int = int(n)

# 2. Generar la lista de números
numeros = []
for i in range(n+1):
	numeros.append(i)

# 3. Imprimir la lista
for x in numeros:
	print(x)