zodiaco = {
    "Aries": ["Sagitario", "Leo", "Acuario"],
    "Tauro": ["Cáncer", "Libra", "Virgo"],
    "Géminis": ["Leo", "Libra", "Géminis", "Capricornio", "Sagitario"],
}

# lee un signo desde el usuario
signo = input("Dame un signo del zodiaco: ")
signo = signo.title()

# obten signos compatibles
if signo in zodiaco.keys():
    # genera una cadena con todos los signos
    zignos_afines: list = zodiaco[signo]
    zignos_afines: str = "\n".join(zignos_afines)

    # imprime el resultado
    print(zignos_afines)
else:
    print("Error: signo no encontrado!")

