# Creando listas vacias
lista_vacia = []
listas_vacia2 = list()

# Iniciand listas con datos
lista_enteros = [4, 8, 3, 2, 9, 11, 4, 1, 4, 3]
#                0  1  2  3  4  5   6  7  8  9
lista_floats = [4.5, 8.5, 2.5, 9.5]
lista_cadenas = ["cuatro", "ocho", "dos"]

print(lista_vacia)
print(lista_enteros)
print(lista_cadenas)

# Creando lista con varios tipos de datos
lista_mix = [4, 4.5, "cuatro"]
lista_listas = [lista_vacia, lista_enteros, lista_mix]

print(lista_listas)

# Tipos de operaciones

print(lista_enteros[0])  # primer elemento
print(lista_enteros[2])  # tercer elemento
print(lista_enteros[9])  # el último elemento
print( len(lista_enteros) )  # cantidad de elementos en una lista
print(lista_enteros[len(lista_enteros)-1])  # el último elemento
print(lista_enteros[-1])  # el último elemento
print("-" * 40)

# Obtener rebanadas (slices)

print(lista_enteros[2:6])
print(lista_enteros[:6])
print(lista_enteros[2:])

print("-" * 40)

# Funciones relacionadas con listas
lista_1 = []
lista_1.append(5)
lista_1.append(10)  # 5, 10
lista_1.insert(0, 1)  # 1, 5, 10
lista_1.append(7)   # 1, 5, 10, 7
lista_1.sort()  #  1, 5, 7, 10

print(lista_1)

# Convertir cadenas a listas o lo contrario
texto = "abcdefg hijk"
lista = list(texto)
print(lista)

lista_2 = texto.split()
print(lista_2)

texto2 = "".join(lista)  # abcdefg hijk
texto3 = ".".join(lista)  # a.b.c.d.e.f.g. .h.i.j.k
print(texto2)
print(texto3)
