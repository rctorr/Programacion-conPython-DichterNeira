def suma(a, b=0):
    """ Calcula y regresa la suma de a con b """
    return a + b

def resta(a, b):
    """ Calcula y regresa la resta de a con b """
    return a - b

def producto(a, b=1):
    """ Calcula y regresa el producto de a con b """
    return a * b
