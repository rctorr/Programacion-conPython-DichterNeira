import csv

# Modelo
def lee_datos(nom_arch):
    """ 
    Lee todos los datos del archivo nom_arch y lo regresa como una lista
    """
    with open(nom_arch) as arch:
        csv_lector = csv.reader(arch)
        lista = list(csv_lector)

    return lista

# Vista
def imprime_lista(inmuebles):
    """
    Imprime la lista de inmuebles en la salida estándar
    """
    columnas = zip(*inmuebles)
    tamanios = [len(max(col, key=len)) for col in columnas]
    formatos = ["{:"+str(t)+"}" for t in tamanios]
    linea = " ".join(formatos)
    for fila in inmuebles:
        print(linea.format(*fila))

def lee_palabras():
    """ Lee la lista de palabras desde la entrada estándar """
    palabras = input("Dame la lista de Tipos de inmuebles: ")
    palabras: list = palabras.split()

    return palabras

# Controlador
def filtra_por(inmuebles, *palabras):
    """
    Filtra la lista de inmuebles en base a la lista de argumentos
    de palabras. Se regresa la lista filtrada.
    """
    filtrados = []
    for inmueble in inmuebles:
        # inmueble -> [1, "fecha", "Tipo", ...]
        if inmueble[2] in palabras:  # "Local" in ("Parking", "Local", "Oficina")
            filtrados.append(inmueble)

    return filtrados


def main():
    """ Función principal del script """
    inmuebles: list = lee_datos("inmuebles.csv")

    # Lee lista de palabras, filtra la lista de inmuebles e imprime
    palabras = lee_palabras()
    filtrados = filtra_por(inmuebles, *palabras)  # unpaking
    imprime_lista(filtrados)

if __name__ == "__main__":
    main()
