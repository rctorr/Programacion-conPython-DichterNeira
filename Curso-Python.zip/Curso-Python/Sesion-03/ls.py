import click
import os
import time

# Modelo
def obtener_lista(carpeta):
	""" Regresa una lista de los archivos de carpeta """
	lista = os.listdir(carpeta)  # lista -> ["ls.py", "inmuebles.csv", ...]
	# [(45635, "dd-mm-yyyy hh:mm:ss", "ls.py"), (3434, fecha, "dos.py"), ]
	datos = []
	for arch in lista:
		ruta = os.path.join(carpeta, arch)
		tamanio = os.path.getsize(ruta)
		fecha = os.path.getmtime(ruta)
		datos.append( (tamanio, fecha, arch) )

	return datos

# Vista
def imprime_lista(archivos):
	""" Imprime la lista de archivos en la salida estándar """
	for fila in archivos:
		fecha: tuple = time.localtime(fila[1])
		fecha: str = time.strftime("%d-%m-%Y %H:%M:%S", fecha)
		print( f"{fila[0]:10}  {fecha:19}  {fila[2]}")

# Controlador - MVC
@click.command()
@click.argument("carpeta", default=".", type=click.Path(exists=True))
def main(carpeta):
	"""
	Imprime la lista de archivos en la carpeta indicada
	"""
	archivos = obtener_lista(carpeta)
	imprime_lista(archivos)


if __name__ == '__main__':
	main()