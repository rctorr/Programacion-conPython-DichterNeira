
MENU = (
	(1, "Helado con oreo", 19),
	(2, "Helado con m&m", 25),
	(3, "Helado con fresas", 22),
	(4, "Helado con brownie", 28)
)


# Zona de funciones

# Vista
def imprime_menu(menu):
	"""
	Imprime la lista de topings en la salida estándar
	"""
	print( f"{menu[0][0]}. {menu[0][1]}" )
	print( f"{menu[1][0]}. {menu[1][1]}" )
	print( f"{menu[2][0]}. {menu[2][1]}" )
	print( f"{menu[3][0]}. {menu[3][1]}" )

# Vista, Modelo
def lee_opcion():
	""" Lee la opción elegida por el usuario desde la entrada estándar """
	opcion: str = input("Elije una opción: ")
	opcion: int = int(opcion)

	return opcion

# Vista
def imprime_precio(precio):
	""" Imprime el precio o mensaje en la salida estándar """
	if precio == None:
		print("El helado no existe!")
	else:
		print( f"El precio del helado es de ${precio} M.N." )

# MVC = Modelo Vista Controlador

# Controlador
def main():
	""" Función principal del programa """
	imprime_menu(MENU)
	opcion = lee_opcion()
	if opcion in [1, 2, 3, 4]:
		precio = MENU[opcion-1][2]
	else:
		precio = None
	imprime_precio(precio)

if __name__ == "__main__":
	main()
	