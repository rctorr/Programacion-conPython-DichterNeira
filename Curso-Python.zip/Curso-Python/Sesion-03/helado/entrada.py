def lee_respuesta():
    """ Leer las opción elegida por el usuario """
    opcion_str = input("Elige el topping: ")
    opcion = int(opcion_str)
    return opcion
