"""
Paquete helado:

Contiene los módulos para el sistema de cobro de un helado
en base la topping.

- entradas: ...
- pantalla: ...
- varios: ...

Constantes:

- MENU: ....
"""



MENU = (
    (1, "Helado con oreo"),     # 0
    #0  1
    (2, "Helado con m&m"),      # 1
    (3, "Helado con fresas"),   # 2
    (4, "Helado con brownie"),  # 3
)
