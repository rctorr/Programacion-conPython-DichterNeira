import helado.varios
from helado import entrada, MENU
from helado.pantalla import imprime_toppings, imprime_precio
# import helado

def main():
    """ Función principal del programa """

    helado.varios.borrar_terminal()
    # 1. Imprimir la lista de opciones en la pantalla
    imprime_toppings(MENU)
    # 2. Leer la opción elegida por el usuario
    opcion = entrada.lee_respuesta()
    # 3. En base a la opción del usuario imprimir el valor del helado
    imprime_precio(opcion)

# Para validar si este script es el programa principal
if __name__ == "__main__":
    main()

